#!/usr/bin/env python
import rospy
from std_msgs.msg import String
from std_srvs.srv import Trigger, TriggerResponse
import random

class SuperPublisher:
    def __init__(self):
        rospy.init_node('super_publisher_node')
        
        # 发布三个话题
        self.pub_fish = rospy.Publisher('/fish', String, queue_size=10)
        self.pub_veggies = rospy.Publisher('/veggies', String, queue_size=10)
        self.pub_fruits = rospy.Publisher('/fruits', String, queue_size=10)
        
        # 订阅付款话题
        rospy.Subscriber('/payment', String, self.payment_callback)
        
        # 服务：提供促销信息
        self.promo_service = rospy.Service('/get_promotion', Trigger, self.promotion_callback)
        
        self.products = {
            'fish': ['salmon', 'tuna', 'trout'],
            'veggies': ['carrot', 'spinach', 'potato'],
            'fruits': ['apple', 'banana', 'orange']
        }
        
        self.paid = False

    def payment_callback(self, msg):
        rospy.loginfo(f"Payment received: {msg.data}")
        self.paid = True

    def promotion_callback(self, req):
        response = TriggerResponse()
        response.success = True
        response.message = "Special promotion: 10% off on all products today!"
        rospy.loginfo("Promotion requested")
        return response

    def publish_products(self):
        rate = rospy.Rate(0.5)  # 2秒发一次
        print(f"hello")
        while not rospy.is_shutdown():
            if self.paid:
                # 只有收到付款后才发布商品
                for category, pub in [('fish', self.pub_fish), ('veggies', self.pub_veggies), ('fruits', self.pub_fruits)]:
                    product = random.choice(self.products[category])
                    print(f"Announcing {category}: {product}")
                    pub.publish(product)
                self.paid = False
            rate.sleep()

if __name__ == '__main__':
    node = SuperPublisher()
    node.publish_products()
