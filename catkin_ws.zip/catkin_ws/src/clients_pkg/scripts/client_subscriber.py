#!/usr/bin/env python
import rospy
from std_msgs.msg import String
from std_srvs.srv import Trigger

class ClientSubscriber:
    def __init__(self):
        rospy.init_node('client_subscriber_node')
        
        self.desired_product = 'apple'

        rospy.Subscriber('/fish', String, self.callback)
        rospy.Subscriber('/veggies', String, self.callback)
        rospy.Subscriber('/fruits', String, self.callback)
        
        self.payment_pub = rospy.Publisher('/payment', String, queue_size=10)
        
        rospy.wait_for_service('/get_promotion')
        self.get_promotion = rospy.ServiceProxy('/get_promotion', Trigger)

    def callback(self, msg):
        print(f"Heard product: {msg.data}")
        if msg.data == self.desired_product:
            rospy.loginfo(f"Found desired product: {msg.data}, paying now!")
            self.payment_pub.publish(f"Paid for {msg.data}")
            try:
                resp = self.get_promotion()
                rospy.loginfo(f"Promotion received: {resp.message}")
            except rospy.ServiceException as e:
                rospy.logwarn(f"Service call failed: {e}")

    def spin(self):
        rospy.spin()

if __name__ == '__main__':
    client = ClientSubscriber()
    client.spin()
